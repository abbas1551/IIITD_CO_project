
def dec_to_bin(dec_str):
    dec_str = int(dec_str[1:])
    binary = bin(dec_str)[2:]
    
    binary = binary.zfill(7)
    return binary


def gen_address(count):
    address = bin(count)[2:]
    address = address.zfill(7)
    return address


def xor(reg1, reg2):
    out = ''
    for i in range(16):
        if reg1[i] == reg2[i]:
            out+='0'
        else:
            out+='1'
    return out

def or_function(reg1, reg2):
    out = ''
    for i in range(16):
        if reg1[i] == '1' or reg2[i] == '1':
            out +='1'
        else:
            out +='0'
    return out

def and_function(reg1, reg2):
    reg1.zfill(16)
    reg2.zfill(16)
    out = ''
    for i in range(16):
        if reg1[i] == 0 or reg2[i] == 0:
            out+='0'
        else:
            out+='1'
    return out


def rs(reg, imm):
    reg = reg.zfill(16)
    reg = '0'*imm+reg[:16-imm]
    return reg
def ls(reg, imm):
    reg = reg.zfill(16)
    reg = reg[16-imm:] + '0'*imm
    return reg

def invert(reg):
    reg.zfill(16)
    out = ''
    for i in range(16):
        if reg[i] == '1':
            out+='0'
        else:
            out+='1'
    return out

def decimal_to_binary(decimal):
    binary = ""
    integer_part = int(decimal)
    fractional_part = decimal - integer_part

    # Convert the integer part to binary
    while integer_part > 0:
        binary = str(integer_part % 2) + binary
        integer_part //= 2

    # Convert the fractional part to binary
    binary += "."

    while fractional_part > 0:
        if len(binary) > 32:
            break  # Limit the precision to 32 bits
        fractional_part *= 2
        bit = int(fractional_part)
        binary += str(bit)
        fractional_part -= bit

    return binary

# # Example usage
# float_number = 1.5
# binary_number = decimal_to_binary(float_number)
# #print(f"The binary representation of {float_number} is: {binary_number}")

# def binary_ISA(binary):
#     binary = binary.split('.')
#     int_part = binary[0]
#     flot_part = binary[1]
#     exp = 0
#     if (int(int_part, 2)>1):
#         while (int(int_part, 2)>1):
#             rev = int_part[-1]
#             flot_part = rev + flot_part
#             int_part = int_part[:len(int_part)-1]
#             exp-=1
#     if (int(int_part, 2) < 1):
#         while (int(int_part, 1) < 1):
#             rev = float_number[0]
#             float_number = float_number[1:]
#             int_part = int_part + float_number
#             exp+=1
#     print(int_part, flot_part, exp)


def bin_to_mne(binary):#binary is a string
    binary = float(binary)
    exp=0
    i=0
    M=0
    P=0
    if (binary<1):
        M=binary
        print(M,exp)
        exit
    else:
        while (binary>1):
           binary=binary/10
          # print(binary)
           i+=1
        i-=1
   
        P=binary*10
       # print(P)
        M=P-1
        exp=i
        return str(round(M,10))[2:].zfill(5) +bin(abs(exp))[2:].zfill(3)
        print(round(M,10),exp)
def mnp_to_bin(mantissa, exp):
    #lhs = bin((int(mantissa, 2) + 1)*10**(int(exp, 2)))[2:]
    #mantissa=int(mantissa,2)
    print(mantissa)
    length=len(mantissa)
    new_mantissa =( int(mantissa)/(10**length))+1
    
    new_exp = int(exp)
    A=new_mantissa*(10**new_exp)
    print(A)
   # new_mantissa =str(int(mantissa) + 10**(len(str(int(mantissa)))))
  
    
# print(decimal_to_binary(4.5))
# print(bin_to_mne(100.1))
# print(mnp_to_bin('00001', '001'))
    

