import sys
import functions
ele = '0000000000000000'
final_list = []
for i in range(128):
    final_list.append(ele)
binary = []
for i in sys.stdin:
    binary.append(i)

A = ['00000','00001','00110','01010','01011','01100', '10000', '10001']
B = ['00010', '01000', '01001']
C = ['00011', '00111', '01110', '01101']
D = ['00100', '00101']
E = ['01111','11100','11101','11111']
F = ['11010']
O = ['10010']
# binary = ['0001000010001000',
# '0001000100001001',
# '0111000000010001',
# '1110100000000110',
# '0000000011010001',
# '0111100000000100',
# '1101000000000000']
counter = 0
stored_memory = []
inv_regs = {'000': '0000000000000000', 
            '001': '0000000000000000', 
            '010': '0000000000000000', 
            '011': '0000000000000000', 
            '100': '0000000000000000', 
            '101': '0000000000000000', 
            '110': '0000000000000000', 
            '111': '0000000000000000'}
def printer(count):
    print(bin(count)[2:].zfill(7),'      ',inv_regs['000'].zfill(16),inv_regs['001'].zfill(16),inv_regs['010'].zfill(16),inv_regs['011'].zfill(16),inv_regs['100'].zfill(16),inv_regs['101'].zfill(16),inv_regs['110'].zfill(16),inv_regs['111'].zfill(16))
 

for i in range(len(binary)):
    final_list[i] = binary[i]


while(counter < len(binary)):
   
    opcode = binary[counter][0:5]
    ra = binary[counter][7:10]
    rb = binary[counter][10:13]
    rc = binary[counter][13:16]
    if opcode in A: #Type A complete
        if opcode == '00000':#add
            inv_regs[ra] = bin(int(inv_regs[rb],2) + int(inv_regs[rc],2))[2:].zfill(16)
            if int(inv_regs[ra], 2) >= 2**7:
                inv_regs['111'] = '0000000000001000'
        elif opcode == '00001':#sub
            inv_regs[ra] = bin(int(inv_regs[rb],2) - int(inv_regs[rc],2))[2:].zfill(16)
            if int(inv_regs[ra], 2) >= 2**7:
                inv_regs['111'] = '0000000000001000'
        elif opcode == '00110':#mul
            inv_regs[ra] = bin(int(inv_regs[rb],2) * int(inv_regs[rc],2))[2:].zfill(16)
            if int(inv_regs[ra], 2) >= 2**7:
                inv_regs['111'] = '0000000000001000'
        elif opcode == '01010':#xor
            inv_regs[ra] = functions.xor(rb, rc)
        elif opcode == '01011':#or
            inv_regs[ra] = functions.or_function(rb, rc)
        elif opcode == '01100':#and
            inv_regs[ra] = functions.and_function(rb, rc)   
        elif opcode == '10000':
            pass
        elif opcode == '10001':
            pass
    elif opcode in B:#type B completed
        imm = binary[counter][9:16]
        r = binary[counter][6:9]
        if opcode == '00010': #mov imm
            inv_regs[r] = imm.zfill(16)
        elif opcode == '01000': #rs
            int_imm = int(imm, 2)
            inv_regs[r] = functions.rs(r, imm)
            pass
        elif opcode == '01001': #ls
            int_imm = int(imm, 2)
            inv_regs[r] = functions.ls(r, imm)
            pass
    elif opcode in C:  #type C completed
        ra = binary[counter][10:13]
        rb = binary[counter][13:16]
        if opcode == '01110':#cmp
            if inv_regs[ra].zfill(16) == inv_regs[rb].zfill(16):
                inv_regs['111'] = '0000000000000001'
            elif int(inv_regs[ra].zfill(16)) > int(inv_regs[rb].zfill(16)):
                inv_regs['111'] = '0000000000000010'
            elif int(inv_regs[ra].zfill(16)) < int(inv_regs[rb].zfill(16)) :
                inv_regs['111'] = '0000000000000100'
            else :
                inv_regs['111'] = '0000000000000000'
        elif opcode == '00011': #mov r1 r2
            inv_regs[ra] = inv_regs[rb]
            inv_regs['111'] = '0000000000000000'
            #print("R4 went to R3")
        elif opcode == '01101':#invert
            inv_regs[ra] = functions.invert(rb)
        elif opcode == '00111':#divide
            if (int(inv_regs[rb], 2) == 0):
                inv_regs['000'] = '0'*16
                inv_regs['001'] = '0'*16
                inv_regs['111'] = '0000000000001000'
            else:
                inv_regs['000'] = bin(int(inv_regs[ra], 2)//int(inv_regs[rb], 2))[2:].zfill(16)
            
    elif opcode in D:  
        r = binary[counter][6:9]
        mem_addr = binary[counter][9:16]
        if opcode == '00100': #load

            pass
        elif opcode == '00101':#store
            stored_memory.append(inv_regs[r])
            final_list[int(mem_addr, 2)] = inv_regs[r]
            pass
        
    elif opcode in E:  #type E completed
        
        mem_address = int(binary[counter][9:], 2)
        if opcode == '11101':
            if inv_regs['111'] == '0000000000000010':
                inv_regs['111'] = '0000000000000000'
                printer(counter)
                final_list[counter] = binary[counter]
                counter = mem_address
                continue
        if opcode == '01111':
            printer(counter)
            final_list[counter] = binary[counter]
            counter = mem_address
            continue
        if opcode == '11100':
            if inv_regs['111'] == '0000000000000100':
                inv_regs['111'] = '0000000000000000'
                printer(counter)
                final_list[counter] = binary[counter]
                counter = mem_address
                continue
            pass
        if opcode == '11111':
            if inv_regs['111'] == '0000000000000001':
                inv_regs['111'] = '0000000000000000'
                printer(counter)
                counter = mem_address
                final_list[counter] = binary[counter]
                continue
            pass
        inv_regs['111'] = '0000000000000000'
    elif opcode in O:
        r = binary[counter][5:8]
        imm = binary[counter][8:]
        inv_regs[r] = imm.zfill(16)


        pass
    final_list[counter] = binary[counter]
    printer(counter)
    #ins_number+=1
    counter+=1


# for i in binary:
#     print(i)
# for i in range(len(binary),len(final_list)- len(binary)):
#     print(final_list[i])
# print(len(binary), len(final_list))
# for i in stored_memory:
#     print(i.zfill(16))
# for i in range(128-len(binary)- len(stored_memory)):
#     print('0'*16)
for i in final_list:
    print(i)