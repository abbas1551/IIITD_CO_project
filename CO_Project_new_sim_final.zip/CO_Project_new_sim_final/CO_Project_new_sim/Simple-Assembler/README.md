# IIITD_CO_project
you will have to design and implement a custom assembler and a custom simulator for a given ISA.
Contribution Report:
1)- Abbas Murtaza(2022012)-Abbas has contributed in making translator and functions modules which were a cruicial part of our project.
The transalator module used in our project converts assembly code to binary which is crucial for our project.
Abbas has implemented efficient algorithms and optimized code to ensure smooth functioning of our project.

2)-Abhishek Jha(2022023)-abhishek has written the output file of our code and he has helped in others also.

3)-Angadjeet(2022071) and Arnav Batra(2022098)-Angad and Arnav took charge of the error generation and runner module.
the error generation code was to identify the errors in the input file or assembly code and show what is the error.
And for the runner module is the main file connecting all the other files of our project.
                          
                    
