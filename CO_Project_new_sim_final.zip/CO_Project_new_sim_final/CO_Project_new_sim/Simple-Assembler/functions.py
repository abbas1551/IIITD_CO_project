import reader

def dec_to_bin(dec_str):
    dec_str = int(dec_str[1:])
    binary = bin(dec_str)[2:]
    
    binary = binary.zfill(7)
    return binary



def gen_address(count):
    address = bin(count)[2:]
    address = address.zfill(7)
    return address

def decimal_to_binary(decimal):
    binary = ""
    integer_part = int(decimal)
    fractional_part = decimal - integer_part

    # Convert the integer part to binary
    while integer_part > 0:
        binary = str(integer_part % 2) + binary
        integer_part //= 2

    # Convert the fractional part to binary
    binary += "."

    while fractional_part > 0:
        if len(binary) > 32:
            break  # Limit the precision to 32 bits
        fractional_part *= 2
        bit = int(fractional_part)
        binary += str(bit)
        fractional_part -= bit

    return binary

def bin_to_mne(binary):#binary is a string
    binary = float(binary)
    exp=0
    i=0
    M=0
    P=0
    if (binary<1):
        M=binary
        print(M,exp)
        exit
    else:
        while (binary>1):
           binary=binary/10
          # print(binary)
           i+=1
        i-=1
   
        P=binary*10
       # print(P)
        M=P-1
        exp=-i
        return str(round(M,10))[2:].zfill(5) +bin(abs(exp))[2:].zfill(3)
        return [str(round(M, 10)).zfill(5), bin(exp)[2:].zfill(3)]
        print(round(M,10), bin(exp))
# print(decimal_to_binary(2.625))
# print(bin_to_mne(decimal_to_binary(2.625)))