copy all the contents of the repository in Simple-Assembler to get the proper output
